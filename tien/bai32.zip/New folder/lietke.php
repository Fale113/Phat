<?php
$sql_lietke_dh = "SELECT * FROM orders,user WHERE orders.userid=user.userid ORDER BY id DESC";
$query_lietke_dh = mysqli_query($mysqli, $sql_lietke_dh);
?>

<p>Liet kee</p>
<table style="width: 100%" border="1" style=" border-collapse: collapse;">

    <tr>
        <th>Id</th>
        <th>Mã đơn hàng</th>
        <th>Tên khách</th>
        <th>Địa chỉ</th>
        <th>Email</th>
        <th>Số Điên thoại</th>
        <th>Tình trạng</th>
        <th>Quản Lý</th>
    </tr>
    <?php
    $i = 0;
    while ($row = mysqli_fetch_array($query_lietke_dh)) {
        $i++ ?>
    <tr>
        <td>
            <?php echo $i ?>
        </td>

        <td>
            <?php echo $row['orderid'] ?>
        </td>
        <td>
            <?php echo $row['fullname'] ?>
        </td>
        <td>
            <?php echo $row['address'] ?>
        </td>
        <td>
            <?php echo $row['email'] ?>
        </td>
        <td>
            <?php echo $row['phonenumber'] ?>
        </td>
        <td>
            <?php
                if ($row['status'] == 1) {
                    echo '<a href="quanlydonhang/xuly.php?status=0&code=' . $row['orderid'] . '">Đơn hàng mới</a>';
                } else {
                    echo 'Đã xem';
                }
                ?>
        </td>
        <td>

            <a href="index.php?action=donhang&query=xemdonhang&code=<?php echo $row['orderid'] ?>">Xem đơn hàng</a>


        </td>
        <td>

            <a href="admin/quanlydonhang/indonhang.php?code=<?php echo $row['orderid'] ?>"><In></In> đơn hàng</a>


        </td>

    </tr>

    <?php }
    ?>
</table>